#!/usr/bin/env python3
"""
Swiss Job Intel — scraper complet validé (mai 2026)
Usage: python3 scrape_ch_jobs.py [profile_cache.json] > /tmp/all_offers.json 2>/tmp/scrape_log.txt

Si profile_cache.json est fourni (ou présent dans le CWD), les primary_terms
du profil remplacent les termes Workday hardcodés.

IMPORTANT: Lancer via terminal(), jamais via execute_code (bloque le réseau).
"""
import urllib.request, urllib.parse, re, json, sys, time, io, os

UA   = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0"
LANG = "fr-CH,fr;q=0.9,en;q=0.8"

# ── Parser les arguments ──────────────────────────────────────────────────────
_profile_arg  = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1].endswith(".json") and not sys.argv[1].startswith("--") else None
_sources_path = None
for _i, _a in enumerate(sys.argv):
    if _a == "--sources" and _i + 1 < len(sys.argv):
        _sources_path = sys.argv[_i + 1]
        break

# ── Charger le profil depuis cache ────────────────────────────────────────────
_profile = None
for _p in [
    _profile_arg,
    os.path.join(os.getcwd(), "profile_cache.json"),
]:
    if _p and os.path.exists(_p):
        try:
            with open(_p, encoding="utf-8") as _f:
                _profile = json.load(_f)
            print(f"[profile] Chargé depuis {_p}", file=sys.stderr)
            break
        except Exception:
            pass

# ── Charger les sources sélectionnées ─────────────────────────────────────────
_selected_ids = None
if _sources_path and os.path.exists(_sources_path):
    try:
        with open(_sources_path, encoding="utf-8") as _f:
            _sel = json.load(_f)
        _selected_ids = {s.get("id") for s in _sel if s.get("id")}
        print(f"[sources] {len(_selected_ids)} sources sélectionnées : {sorted(_selected_ids)}", file=sys.stderr)
    except Exception as e:
        print(f"[sources] Erreur lecture {_sources_path}: {e} — toutes les sources actives", file=sys.stderr)

def source_active(sid: str) -> bool:
    """True si la source doit être scrapée (ou si pas de liste → toutes actives)."""
    return _selected_ids is None or sid in _selected_ids

# ── Helpers ───────────────────────────────────────────────────────────────────

def fetch(url, data=None, extra_headers=None, timeout=15):
    h = {
        "User-Agent": UA,
        "Accept-Language": LANG,
        # CRITICAL: always specify Accept or Workday returns empty pages
        "Accept": "text/html,application/json,*/*",
    }
    if extra_headers:
        h.update(extra_headers)
    try:
        req = urllib.request.Request(url, data=data, headers=h)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read().decode("utf-8", errors="replace")
    except Exception as e:
        return ""

def norm_snippet(text, maxlen=600):
    t = re.sub(r'<script[^>]*>.*?</script>', ' ', str(text), flags=re.DOTALL)
    t = re.sub(r'<style[^>]*>.*?</style>', ' ', t, flags=re.DOTALL)
    t = re.sub(r'<[^>]+>', ' ', t)
    t = re.sub(r'&[a-z]+;', ' ', t)
    t = re.sub(r'\s+', ' ', t).strip()
    return t[:maxlen]

def extract_jsonld_jobposting(html):
    """Extract all JobPosting JSON-LD blocks from HTML."""
    blocks = re.findall(
        r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        html, re.DOTALL | re.IGNORECASE
    )
    jobs = []
    for b in blocks:
        try:
            d = json.loads(b.strip())
            items = d if isinstance(d, list) else [d]
            for i in items:
                if i.get("@type") == "JobPosting":
                    jobs.append(i)
        except:
            pass
    return jobs

def _coerce_url(value):
    """Normalise les variantes JSON-LD d'URL en chaîne exploitable."""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return value.get("@id", "") or value.get("url", "") or value.get("id", "")
    if isinstance(value, list):
        for item in value:
            url = _coerce_url(item)
            if url:
                return url
    return ""

def from_jsonld(ld, source, fallback_url=""):
    """Convert a JSON-LD JobPosting dict to our standard offer dict.
    Handles both dict and list for jobLocation / hiringOrganization.
    """
    jloc = ld.get("jobLocation") or {}
    if isinstance(jloc, list): jloc = jloc[0] if jloc else {}
    loc_city = jloc.get("address", {}).get("addressLocality", "") if isinstance(jloc, dict) else ""

    horg = ld.get("hiringOrganization") or {}
    if isinstance(horg, list): horg = horg[0] if horg else {}
    employer_name = horg.get("name", "") if isinstance(horg, dict) else ""

    return make_offer(
        title       = ld.get("title", ""),
        employer    = employer_name or source,
        location    = loc_city,
        url         = _coerce_url(ld.get("url", "")) or _coerce_url(ld.get("mainEntityOfPage", "")) or fallback_url,
        date        = ld.get("datePosted", ""),
        description = ld.get("description", ""),
        source      = source,
    )

def make_offer(title, employer, location, url, date, description, source):
    return {
        "title":    title,
        "employer": employer,
        "location": location,
        "url":      url,
        "date":     date,
        "snippet":  norm_snippet(description, 600),
        "source":   source,
    }

# ── State ─────────────────────────────────────────────────────────────────────

all_offers = []
seen_urls  = set()

def add(offer):
    key = offer.get("url") or (offer["title"] + "|" + offer["employer"])
    if key and key not in seen_urls:
        seen_urls.add(key)
        all_offers.append(offer)

log = lambda msg: print(msg, file=sys.stderr)

# ── Vérification profil (obligatoire pour les termes de recherche) ────────────
if _profile and _profile.get("primary_terms"):
    print(f"[profile] {len(_profile['primary_terms'])} termes depuis le profil candidat", file=sys.stderr)
else:
    print("❌ Aucun profil candidat trouvé — impossible de déterminer les termes de recherche.", file=sys.stderr)
    print("   Fournir profile_cache.json en argument ou le placer dans le répertoire courant.", file=sys.stderr)
    print("   Générer le profil : lancer le skill swiss-job-intel (Phase 0 → Phase 2C).", file=sys.stderr)
    sys.exit(1)

# ═══════════════════════════════════════════════════════════════════════════════
# SOURCE 1 — SWISSCOM WORKDAY (multi_domain — API Workday)
# POST JSON API → enrichissement description via HTML
# ═══════════════════════════════════════════════════════════════════════════════

if source_active("swisscom_workday"):
    seen_sw = set()
    for term in _profile["primary_terms"]:
        body = json.dumps({"limit": 20, "offset": 0, "searchText": term, "locations": []}).encode()
        raw = fetch(
            "https://swisscom.wd103.myworkdayjobs.com/wday/cxs/swisscom/SwisscomExternalCareers/jobs",
            data=body,
            extra_headers={"Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest"}
        )
        try:
            d = json.loads(raw)
            for j in d.get("jobPostings", []):
                path = j.get("externalPath", "")
                if path in seen_sw: continue
                seen_sw.add(path)
                add(make_offer(
                    title       = j.get("title", ""),
                    employer    = "Swisscom",
                    location    = j.get("locationsText", ""),
                    url         = "https://swisscom.wd103.myworkdayjobs.com" + path,
                    date        = j.get("postedOn", ""),
                    description = "",
                    source      = "swisscom_workday",
                ))
        except:
            pass
        time.sleep(0.3)

    log(f"[Swisscom] {sum(1 for o in all_offers if o['source']=='swisscom_workday')} offres uniques")

    enriched = 0
    for o in [o for o in all_offers if o["source"] == "swisscom_workday"]:
        m = re.search(r'myworkdayjobs\.com(/job/.+)', o["url"])
        if not m: continue
        html = fetch(
            "https://swisscom.wd103.myworkdayjobs.com/SwisscomExternalCareers" + m.group(1),
            extra_headers={"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}
        )
        jobs = extract_jsonld_jobposting(html)
        if jobs:
            o["snippet"] = norm_snippet(jobs[0].get("description", ""), 600)
            enriched += 1
        time.sleep(0.25)
    log(f"   → {enriched} descriptions enrichies")
else:
    log("[Swisscom] ignoré (non sélectionné)")

# ═══════════════════════════════════════════════════════════════════════════════
# SOURCE 2 — ANSAM (generalist — Teamtailor JSON-LD)
# Pattern: scraper listing → follow chaque URL → JSON-LD
# ═══════════════════════════════════════════════════════════════════════════════

if source_active("ansam"):
    html = fetch("https://carrieres.ansam.ch/jobs")
    ansam_urls = list(set(re.findall(r'https://carrieres\.ansam\.ch/jobs/\d+[^"\'>\s]*', html)))
    log(f"[ANSAM] {len(ansam_urls)} URLs trouvées")
    for url in ansam_urls:
        html2 = fetch(url)
        for ld in extract_jsonld_jobposting(html2):
            add(from_jsonld(ld, "ansam", fallback_url=url))
        time.sleep(0.3)
    log(f"   → {sum(1 for o in all_offers if o['source']=='ansam')} offres")
else:
    log("[ANSAM] ignoré (non sélectionné)")

# ═══════════════════════════════════════════════════════════════════════════════
# SOURCE 3 — ADMIN FÉDÉRAL OHWS (multi_domain — JSON API)
# ═══════════════════════════════════════════════════════════════════════════════

if source_active("admin_federal"):
    raw = fetch("https://ohws.prospective.ch/public/v1/medium/1000625?lang=fr&limit=80")
    try:
        data = json.loads(raw)
        jobs = data if isinstance(data, list) else data.get("items", data.get("jobs", []))
        for j in jobs:
            add(make_offer(
                title       = j.get("title") or j.get("jobTitle", ""),
                employer    = j.get("company") or j.get("employer", ""),
                location    = j.get("location") or j.get("city", ""),
                url         = j.get("url") or j.get("link", ""),
                date        = j.get("date") or j.get("publicationDate", ""),
                description = str(j.get("description") or j.get("text", ""))[:300],
                source      = "admin_federal",
            ))
        log(f"[Admin fédéral] {sum(1 for o in all_offers if o['source']=='admin_federal')} offres")
    except:
        log("[Admin fédéral] Vide ou indisponible — skip")
else:
    log("[Admin fédéral] ignoré (non sélectionné)")

# ═══════════════════════════════════════════════════════════════════════════════
# SOURCE 4 — CIGES (specialized IT/formation — WordPress JSON-LD)
# ═══════════════════════════════════════════════════════════════════════════════

if source_active("ciges"):
    html = fetch("https://www.ciges.ch/carriere/")
    ciges_urls = list(set(re.findall(r'https://www\.ciges\.ch/job/[^"\'>\s]+', html)))
    for url in ciges_urls:
        html2 = fetch(url)
        for ld in extract_jsonld_jobposting(html2):
            add(from_jsonld(ld, "ciges", fallback_url=url))
        time.sleep(0.3)
    log(f"[CIGES] {sum(1 for o in all_offers if o['source']=='ciges')} offres")
else:
    log("[CIGES] ignoré (non sélectionné)")

# ═══════════════════════════════════════════════════════════════════════════════
# SOURCE 5 — JOBUP.CH (generalist — listing HTML → detail JSON-LD)
# Listing /fr/emplois/?term={term} → URLs /fr/emplois/detail/UUID/ → JSON-LD
# ═══════════════════════════════════════════════════════════════════════════════

if source_active("jobup"):
    _terms_jobup = _profile["primary_terms"][:7]
    _seen_jobup: set[str] = set()
    _jobup_detail_urls: list[str] = []

    for term in _terms_jobup:
        encoded = urllib.parse.quote_plus(term)
        html = fetch(f"https://www.jobup.ch/fr/emplois/?term={encoded}")
        paths = re.findall(r'href="(/fr/emplois/detail/[a-f0-9-]+/)"', html)
        for p in paths:
            if p not in _seen_jobup:
                _seen_jobup.add(p)
                _jobup_detail_urls.append(p)
        time.sleep(0.3)
        if len(_jobup_detail_urls) >= 60:
            break

    log(f"[Jobup] {len(_jobup_detail_urls)} URLs d'offres uniques")
    for path in _jobup_detail_urls:
        detail_url = f"https://www.jobup.ch{path}"
        html2 = fetch(detail_url)
        for ld in extract_jsonld_jobposting(html2):
            add(from_jsonld(ld, "jobup", fallback_url=detail_url))
        time.sleep(0.25)
    log(f"   → {sum(1 for o in all_offers if o['source']=='jobup')} offres")
else:
    log("[Jobup] ignoré (non sélectionné)")

# ═══════════════════════════════════════════════════════════════════════════════
# SOURCE 6 — JOBS.CH (generalist — listing HTML DE → detail JSON-LD)
# Listing /de/stellenangebote/?term={term} → URLs /de/stellenangebote/detail/UUID/
# Note: l'URL française renvoie 31 chars (SPA shell), l'URL DE fonctionne
# ═══════════════════════════════════════════════════════════════════════════════

if source_active("jobs_ch"):
    _terms_jobs_ch = _profile["primary_terms"][:7]
    _seen_jobs_ch: set[str] = set()
    _jobs_ch_detail_urls: list[str] = []

    for term in _terms_jobs_ch:
        encoded = urllib.parse.quote_plus(term)
        html = fetch(f"https://www.jobs.ch/de/stellenangebote/?term={encoded}")
        paths = re.findall(r'href="(/de/stellenangebote/detail/[a-f0-9-]+/)"', html)
        for p in paths:
            if p not in _seen_jobs_ch:
                _seen_jobs_ch.add(p)
                _jobs_ch_detail_urls.append(p)
        time.sleep(0.3)
        if len(_jobs_ch_detail_urls) >= 60:
            break

    log(f"[Jobs.ch] {len(_jobs_ch_detail_urls)} URLs d'offres uniques")
    for path in _jobs_ch_detail_urls:
        detail_url = f"https://www.jobs.ch{path}"
        html2 = fetch(detail_url)
        for ld in extract_jsonld_jobposting(html2):
            add(from_jsonld(ld, "jobs_ch", fallback_url=detail_url))
        time.sleep(0.25)
    log(f"   → {sum(1 for o in all_offers if o['source']=='jobs_ch')} offres")
else:
    log("[Jobs.ch] ignoré (non sélectionné)")

# ═══════════════════════════════════════════════════════════════════════════════
# SOURCE 7 — SUISSETALENT.CH (generalist — JSON-LD directement dans le listing)
# Listing /emplois?term={term} contient 20 JobPosting JSON-LD par page
# ═══════════════════════════════════════════════════════════════════════════════

if source_active("suissetalent"):
    _terms_st = _profile["primary_terms"][:8]
    _seen_st: set[str] = set()

    for term in _terms_st:
        encoded = urllib.parse.quote_plus(term)
        html = fetch(f"https://www.suissetalent.ch/emplois?term={encoded}")
        for ld in extract_jsonld_jobposting(html):
            url_key = (
                _coerce_url(ld.get("url", "")) or
                _coerce_url(ld.get("mainEntityOfPage", "")) or
                (ld.get("title", "") + "|" + str(ld.get("hiringOrganization", "")))
            )
            if url_key and url_key not in _seen_st:
                _seen_st.add(url_key)
                add(from_jsonld(ld, "suissetalent"))
        time.sleep(0.3)

    log(f"[Suissetalent] {sum(1 for o in all_offers if o['source']=='suissetalent')} offres")
else:
    log("[Suissetalent] ignoré (non sélectionné)")

# ═══════════════════════════════════════════════════════════════════════════════
# OUTPUT
# ═══════════════════════════════════════════════════════════════════════════════

by_source = {}
for o in all_offers:
    by_source[o["source"]] = by_source.get(o["source"], 0) + 1

log(f"\n{'='*60}")
log(f"TOTAL: {len(all_offers)} offres uniques")
for s, n in sorted(by_source.items()):
    with_desc = sum(1 for o in all_offers if o["source"] == s and o.get("snippet", "").strip())
    log(f"  {s}: {n} offres ({with_desc} avec description)")

print(json.dumps(all_offers, ensure_ascii=False, indent=2))
